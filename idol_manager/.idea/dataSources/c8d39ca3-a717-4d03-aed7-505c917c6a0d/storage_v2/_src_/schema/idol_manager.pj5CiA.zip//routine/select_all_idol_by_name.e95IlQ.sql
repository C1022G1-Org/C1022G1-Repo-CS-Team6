create
    definer = root@localhost procedure select_all_idol_by_name(IN name_find varchar(10))
BEGIN
    SELECT * FROM idol WHERE name LIKE CONCAT('%', name_find, '%') ;
END;

