create
    definer = root@localhost procedure delete_idol(IN id int)
BEGIN
    DELETE
    FROM idol i
    WHERE i.id = id;
END;

