create
    definer = root@localhost procedure update_idol_by_id(IN name varchar(50), IN gender varchar(10),
                                                         IN date_of_birth varchar(15), IN country varchar(50),
                                                         IN popular varchar(50), IN skill varchar(50))
BEGIN
    UPDATE idol i
    SET i.name          = name,
        i.gender        = gender,
        i.date_of_birth = date_of_birth,
        i.country       = country,
        i.popular       = popular,
        i.skill         = skill
    WHERE i.id = id;
END;

