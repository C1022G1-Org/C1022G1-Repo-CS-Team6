create
    definer = root@localhost procedure add_idols(IN name varchar(50), IN gender varchar(10),
                                                 IN date_of_birth varchar(15), IN country varchar(50),
                                                 IN popular varchar(50), IN skill varchar(50))
BEGIN
    INSERT INTO idol(name, gender, date_of_birth, country, popular, skill)
    VALUES (name, gender, date_of_birth, country, popular, skill);
END;

